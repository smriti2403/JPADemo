package com.accenture.lkm.service;

public interface EmployeeService {
	public void removeEmployeeById(int employeeId) throws Exception;

}
