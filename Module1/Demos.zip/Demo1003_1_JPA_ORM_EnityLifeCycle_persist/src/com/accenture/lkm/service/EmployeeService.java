package com.accenture.lkm.service;

import com.accenture.lkm.businessbean.EmployeeBean;

public interface EmployeeService {
	Integer addEmployee(EmployeeBean employee) throws Exception;

}
