package com.accenture.lkm.service;

import java.util.List;

public interface EmployeeService {
	public List<Object> stringFunctionsDemo() throws Exception;
	public List<Object> dateFunctionsDemo() throws Exception;
	public List<Object> aggregateFunctionsDemo() throws Exception;
}
