package com.accenture.lkm.dao;

import java.util.List;

public interface EmployeeDAO {
	public List<Object> stringFunctionsDemo() throws Exception;
	public List<Object> dateFunctionsDemo() throws Exception;
	public List<Object> aggregateFunctionsDemo() throws Exception;
}
