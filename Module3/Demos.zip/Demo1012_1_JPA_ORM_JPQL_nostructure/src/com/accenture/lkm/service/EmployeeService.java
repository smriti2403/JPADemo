package com.accenture.lkm.service;

public interface EmployeeService {
	public void retrieveEmployeeDetails() throws Exception;
	public void retrieveEmployeeDetailsUsingHibernateProvider() throws Exception;

}
